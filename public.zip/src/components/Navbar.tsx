import { AppBar, Toolbar, Typography, Avatar, Box } from '@mui/material';
export default function Navbar() {
 return (
<AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
<Toolbar>
<Typography variant="h6" sx={{ flexGrow: 1 }}>
         Project Ops / Delivery System
</Typography>
<Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
<Typography>Admin</Typography>
<Avatar>N</Avatar>
</Box>
</Toolbar>
</AppBar>
 );
}