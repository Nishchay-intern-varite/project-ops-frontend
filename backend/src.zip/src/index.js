const express = require('express');
const cors = require('cors');
const supabase = require('./supabaseClient');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const app = express();
app.use(cors());
app.use(express.json());
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'projectops_secret';
// ==================== ROOT ====================
app.get('/', function(req, res) {
 res.json({ message: 'Backend Running' });
});
// ==================== AUTH ====================
app.post('/auth/register', async function(req, res) {
 try {
   const { name, email, password } = req.body;
   if (!name || !email || !password) {
     return res.status(400).json({ message: 'All fields are required' });
   }
   const { data: existingUser } = await supabase
     .from('users').select('*').eq('email', email).single();
   if (existingUser) {
     return res.status(400).json({ message: 'User already exists' });
   }
   const hashedPassword = await bcrypt.hash(password, 10);
   const { data, error } = await supabase
     .from('users')
     .insert([{ name, email, password: hashedPassword }])
     .select();
   if (error) return res.status(400).json(error);
   res.status(201).json({ message: 'User registered successfully', user: data });
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.post('/auth/login', async function(req, res) {
 try {
   const { email, password } = req.body;
   if (!email || !password) {
     return res.status(400).json({ message: 'All fields are required' });
   }
   const { data: user, error } = await supabase
     .from('users').select('*').eq('email', email).single();
   if (error || !user) {
     return res.status(401).json({ message: 'Invalid email or password' });
   }
   const isMatch = await bcrypt.compare(password, user.password);
   if (!isMatch) {
     return res.status(401).json({ message: 'Invalid email or password' });
   }
   const token = jwt.sign(
     { id: user.id, email: user.email, role: user.role },
     JWT_SECRET,
     { expiresIn: '1d' }
   );
   res.json({
     message: 'Login successful',
     token,
     user: { id: user.id, name: user.name, email: user.email, role: user.role }
   });
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
// ==================== PROJECTS ====================
app.get('/projects', async function(req, res) {
 try {
   const { data, error } = await supabase.from('projects').select('*');
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.post('/projects', async function(req, res) {
 try {
   const { name, description } = req.body;
   if (!name) return res.status(400).json({ message: 'Project name is required' });
   const { data, error } = await supabase
     .from('projects').insert([{ name, description }]).select();
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.put('/projects/:id', async function(req, res) {
 try {
   const { id } = req.params;
   const { name, description, status } = req.body;
   const { data, error } = await supabase
     .from('projects').update({ name, description, status }).eq('id', id).select();
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.delete('/projects/:id', async function(req, res) {
 try {
   const { id } = req.params;
   const { error } = await supabase.from('projects').delete().eq('id', id);
   if (error) return res.status(400).json(error);
   res.json({ message: 'Project deleted successfully' });
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
// ==================== TASKS ====================
app.get('/tasks', async function(req, res) {
 try {
   const { data, error } = await supabase.from('tasks').select('*');
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.post('/tasks', async function(req, res) {
 try {
   const { title, description, status, priority, project_id, due_date } = req.body;
   if (!title) return res.status(400).json({ message: 'Title is required' });
   const { data, error } = await supabase
     .from('tasks')
     .insert([{ title, description, status, priority, project_id, due_date }])
     .select();
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.put('/tasks/:id', async function(req, res) {
 try {
   const { id } = req.params;
   const { title, description, status, priority, due_date } = req.body;
   const { data, error } = await supabase
     .from('tasks').update({ title, description, status, priority, due_date }).eq('id', id).select();
   if (error) return res.status(400).json(error);
   res.json(data);
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
app.delete('/tasks/:id', async function(req, res) {
 try {
   const { id } = req.params;
   const { error } = await supabase.from('tasks').delete().eq('id', id);
   if (error) return res.status(400).json(error);
   res.json({ message: 'Task deleted successfully' });
 } catch (err) {
   res.status(500).json({ message: 'Server Error', error: err.message });
 }
});
// ==================== SERVER ====================
app.listen(PORT, function() {
 console.log('Backend running on port ' + PORT);
});